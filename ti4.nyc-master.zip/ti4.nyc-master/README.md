# Ti4.NYC

## What is this about?

This is a python app I built to help schedule games for a Twilight Imperium League I help organize in NYC. It's hosted on AWS and currently live at [ti4.nyc](https://ti4.nyc/).

It uses alambic to handle database migrations, Recaptcha APIs to mitigate spammers and sendgrid for sending emails out to participants.
